import requests
import json
import time
from datetime import datetime

# Configure logging
def log_message(message):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    print(f"[{timestamp}] {message}")

# Test results storage
test_results = {
    "login": {"status": None, "time": None, "token": None},
    "get_initial_todos": {"status": None, "time": None, "count": 0},
    "create_todo": {"status": None, "time": None, "id": None},
    "update_todo": {"status": None, "time": None},
    "delete_todo": {"status": None, "time": None},
    "final_check": {"status": None, "time": None, "count": 0}
}

# Base configuration
BASE_URL = "http://localhost:5000/api"
USERNAME = "testuser"
PASSWORD = "testpass"

headers = {
    "Content-Type": "application/json"
}

def log_response(response, operation):
    """Helper function to log API responses consistently"""
    log_message(f"{operation} - Status Code: {response.status_code}")
    if response.text:
        try:
            log_message(f"Response Body: {json.dumps(response.json(), indent=2)}")
        except ValueError:
            log_message(f"Response Text: {response.text}")
    else:
        log_message("No response body")
    log_message(f"Response Time: {response.elapsed.total_seconds():.3f} seconds")
    return response

def login():
    """Authenticate and get JWT token"""
    url = f"{BASE_URL}/auth/login"
    data = {
        "username": USERNAME,
        "password": PASSWORD
    }
    
    log_message(f"Attempting login with username: {USERNAME}")
    start_time = time.time()
    
    try:
        response = requests.post(url, headers=headers, data=json.dumps(data))
        response = log_response(response, "LOGIN")
        
        if response.status_code == 200:
            token = response.json().get("token")
            if token:
                headers["Authorization"] = f"Bearer {token}"
                log_message("Successfully obtained authentication token")
                test_results["login"].update({
                    "status": "PASS",
                    "time": response.elapsed.total_seconds(),
                    "token": f"{token[:15]}... (truncated)"
                })
                return token
            else:
                log_message("Token not found in response")
                test_results["login"]["status"] = "FAIL - No token"
                return None
        else:
            log_message("Login failed")
            test_results["login"]["status"] = f"FAIL - Status {response.status_code}"
            return None
            
    except requests.exceptions.RequestException as e:
        log_message(f"Login request failed: {str(e)}")
        test_results["login"]["status"] = f"FAIL - Exception: {str(e)}"
        return None
    finally:
        total_time = time.time() - start_time
        log_message(f"Login total time: {total_time:.3f} seconds")
        test_results["login"]["time"] = total_time

def get_todos(step_name):
    """Retrieve all todo items"""
    url = f"{BASE_URL}/todos"
    log_message(f"Fetching all todo items ({step_name})...")
    start_time = time.time()
    
    try:
        response = requests.get(url, headers=headers)
        response = log_response(response, f"GET TODOS ({step_name})")
        
        todos = response.json() if response.text else None
        count = len(todos.get('todos', [])) if todos and 'todos' in todos else 0
        
        test_results[step_name].update({
            "status": "PASS" if response.status_code == 200 else f"FAIL - Status {response.status_code}",
            "time": response.elapsed.total_seconds(),
            "count": count
        })
        
        return todos
    except requests.exceptions.RequestException as e:
        log_message(f"Get todos request failed: {str(e)}")
        test_results[step_name]["status"] = f"FAIL - Exception: {str(e)}"
        return None
    finally:
        total_time = time.time() - start_time
        log_message(f"Get todos total time ({step_name}): {total_time:.3f} seconds")
        test_results[step_name]["time"] = total_time

def create_todo():
    """Create a new todo item"""
    url = f"{BASE_URL}/todos"
    data = {
        "title": "New learning",
        "description": "API Automation with python"
    }
    
    log_message("Creating new todo item...")
    log_message(f"Request payload: {json.dumps(data, indent=2)}")
    start_time = time.time()
    
    try:
        response = requests.post(url, headers=headers, data=json.dumps(data))
        response = log_response(response, "CREATE TODO")
        
        if response.status_code == 201:
            todo_id = response.json().get("id")
            log_message(f"Successfully created todo with ID: {todo_id}")
            test_results["create_todo"].update({
                "status": "PASS",
                "time": response.elapsed.total_seconds(),
                "id": todo_id
            })
            return todo_id
        
        test_results["create_todo"]["status"] = f"FAIL - Status {response.status_code}"
        return None
    except requests.exceptions.RequestException as e:
        log_message(f"Create todo request failed: {str(e)}")
        test_results["create_todo"]["status"] = f"FAIL - Exception: {str(e)}"
        return None
    finally:
        total_time = time.time() - start_time
        log_message(f"Create todo total time: {total_time:.3f} seconds")
        test_results["create_todo"]["time"] = total_time

def update_todo(todo_id):
    """Update an existing todo item"""
    url = f"{BASE_URL}/todos/{todo_id}"
    data = {
        "title": "Updated title",
        "description": "Updated description",
        "completed": True
    }
    
    log_message(f"Updating todo ID {todo_id}...")
    log_message(f"Request payload: {json.dumps(data, indent=2)}")
    start_time = time.time()
    
    try:
        response = requests.put(url, headers=headers, data=json.dumps(data))
        response = log_response(response, "UPDATE TODO")
        
        status = "PASS" if response.status_code == 200 else f"FAIL - Status {response.status_code}"
        test_results["update_todo"].update({
            "status": status,
            "time": response.elapsed.total_seconds()
        })
        return response.status_code == 200
    except requests.exceptions.RequestException as e:
        log_message(f"Update todo request failed: {str(e)}")
        test_results["update_todo"]["status"] = f"FAIL - Exception: {str(e)}"
        return False
    finally:
        total_time = time.time() - start_time
        log_message(f"Update todo total time: {total_time:.3f} seconds")
        test_results["update_todo"]["time"] = total_time

def delete_todo(todo_id):
    """Delete a todo item"""
    url = f"{BASE_URL}/todos/{todo_id}"
    log_message(f"Deleting todo ID {todo_id}...")
    start_time = time.time()
    
    try:
        response = requests.delete(url, headers=headers)
        response = log_response(response, "DELETE TODO")
        
        status = "PASS" if response.status_code == 200 else f"FAIL - Status {response.status_code}"
        test_results["delete_todo"].update({
            "status": status,
            "time": response.elapsed.total_seconds()
        })
        return response.status_code == 200
    except requests.exceptions.RequestException as e:
        log_message(f"Delete todo request failed: {str(e)}")
        test_results["delete_todo"]["status"] = f"FAIL - Exception: {str(e)}"
        return False
    finally:
        total_time = time.time() - start_time
        log_message(f"Delete todo total time: {total_time:.3f} seconds")
        test_results["delete_todo"]["time"] = total_time

def print_summary():
    """Print a comprehensive test summary"""
    log_message("\n" + "="*50)
    log_message("TEST EXECUTION SUMMARY")
    log_message("="*50)
    
    # Calculate totals
    total_time = sum(
        step["time"] for step in test_results.values() 
        if step["time"] is not None
    )
    passed = sum(
        1 for step in test_results.values() 
        if step["status"] and step["status"].startswith("PASS")
    )
    total_steps = len(test_results)
    
    log_message(f"\nEXECUTION OVERVIEW:")
    log_message(f"Total Steps: {total_steps}")
    log_message(f"Passed: {passed}")
    log_message(f"Failed: {total_steps - passed}")
    log_message(f"Total Execution Time: {total_time:.3f} seconds")
    
    log_message("\nDETAILED RESULTS:")
    for step, result in test_results.items():
        log_message(f"\n{step.replace('_', ' ').title()}:")
        for k, v in result.items():
            if v is not None:
                log_message(f"  {k}: {v}")

def main_flow():
    """Execute the complete test flow"""
    log_message("Starting API automation test sequence")
    log_message("="*50)
    
    # 1. Authentication
    token = login()
    if not token:
        log_message("Authentication failed. Aborting test sequence.")
        print_summary()
        return
    
    # 2. Initial fetch of todos
    log_message("\nStep 1: Fetch initial todo items")
    initial_todos = get_todos("get_initial_todos")
    
    # 3. Create new todo
    log_message("\nStep 2: Create new todo item")
    todo_id = create_todo()
    
    if todo_id:
        # 4. Verify creation by fetching todos again
        log_message("\nStep 3: Verify todo creation")
        get_todos("final_check")  # First verification
        
        # 5. Update the todo
        log_message("\nStep 4: Update the todo")
        if update_todo(todo_id):
            # 6. Verify update
            log_message("\nStep 5: Verify todo update")
            get_todos("final_check")  # Second verification
        
        # 7. Delete the todo
        log_message("\nStep 6: Delete the todo")
        if delete_todo(todo_id):
            # 8. Final verification
            log_message("\nStep 7: Verify todo deletion")
            get_todos("final_check")  # Final verification
    
    print_summary()
    log_message("\nTest sequence completed")
    log_message("="*50)

if __name__ == "__main__":
    main_flow()
    # For Windows systems - keep the window open
    input("Press any key to continue . . .")